package com.example.mvmmretrofitexample.adapter;

public class ArticleAdapter {
}
