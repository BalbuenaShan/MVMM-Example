package com.example.mvmmretrofitexample.retrofit;

import com.example.mvmmretrofitexample.model.Article;
import static com.example.mvmmretrofitexample.constant.AppConstant.API_KEY;
import com.example.mvmmretrofitexample.response.ArticleResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiRequest {

    @GET("top-headlines?sources=techcrunch&apiKey="+API_KEY)
    Call<ArticleResponse> getTopHeadlines();

}