package com.example.mvmmretrofitexample.repository;

public class ArticleRepository {

}
