package com.example.mvmmretrofitexample.view_model;

public class ArticleViewModel {
}
