package com.example.mvmmretrofitexample.constant;

public class AppConstant {
    public static final String BASE_URL="";

    public static final String API_KEY="";

}
